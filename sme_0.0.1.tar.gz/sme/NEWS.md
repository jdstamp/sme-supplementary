# sme 0.0.1

* Version that was used in the publication of SME.

