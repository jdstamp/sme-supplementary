#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>

using namespace std;

int count_samples(std::string filename);

int count_fam(std::string filename);

int count_snps_bim(std::string filename);
