gg_asymp_se.cpp: The initial version (purely by Ali, no fix effect for target snp etc included)

gg_asymp_se2.cpp: Testing gxg component for multiple components jointly (used to not fix the target index, now change to fix target index)

gg_asymp_se3.cpp: testing only one gxg component in a certain region (The index is not fixed correctly)

gg_asymp_se_ali.cpp: testing the one gxg component in a certain region (with target snp index fixed correctly)
